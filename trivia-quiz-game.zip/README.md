# trivia-quiz-game
Multiplayer Trivia game app, with rules loosely based on the popular   HQ (game)
